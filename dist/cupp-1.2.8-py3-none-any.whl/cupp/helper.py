class CONFIG_DATA:
    years = []
    for i in range(1990, 2023):
        years.append(i)
    chars = ['!', '@', '#', '$', '%%', '&', '*']
    leet = {"a": "4", "i": "1", "e": "3", "t": "7",
            "o": "0", "s": "5", "g": "9", "z": "2"}
    threshold = 200
    wcfrom = 5
    wcto = 12
    numfrom = 0
    numto = 100
